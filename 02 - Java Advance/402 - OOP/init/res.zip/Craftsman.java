public abstract class Craftsman implements ICraft {
    public abstract String craftsmanSkill();
}
