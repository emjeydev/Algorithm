public class Potter {
    // Implement Potter class
}
