public abstract class Craftsman {
    public abstract String craftsmanSkill();
}
