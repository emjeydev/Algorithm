public class Jeweler {
    // Implement Jeweler class
}
