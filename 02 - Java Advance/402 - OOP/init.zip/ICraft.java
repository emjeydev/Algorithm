public interface ICraft {
    void createItem();
    void displayItem();
    void sellItem();
}
