package exception;

public class ColorTransparencyException extends Exception {
    public ColorTransparencyException() {
        super();
    }
}
