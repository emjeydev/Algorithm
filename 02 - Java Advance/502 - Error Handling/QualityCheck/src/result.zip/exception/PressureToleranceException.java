package exception;

public class PressureToleranceException extends Exception {
    public PressureToleranceException() {
        super();
    }
}
