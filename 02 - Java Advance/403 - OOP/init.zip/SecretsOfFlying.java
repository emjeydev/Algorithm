public class SecretsOfFlying {
    private String spellName = "Levitation";

    public String castSpell() {
        return "Flying high with " + spellName + "!";
    }

    private String revealHiddenSpell() {
        return "This is a hidden spell: Invisibility";
    }
}