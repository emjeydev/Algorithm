import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class MagicReflection {
    public Class[] getClasses(){
        throw new UnsupportedOperationException("Not implemented yet.");
    }

    public Method[] getMethods(String className){
        throw new UnsupportedOperationException("Not implemented yet.");
    }

    public String callRevealHiddenSpell(){
        throw new UnsupportedOperationException("Not implemented yet.");
    }

    public String callCastSpell(String spellName){
        throw new UnsupportedOperationException("Not implemented yet.");
    }
}
