public class JavaDonLibrary {
    class A {
        public void m1() {}
        public void m2(int a, int b) {}
    }
    class B {
        public void m3(int c) {}
    }
}