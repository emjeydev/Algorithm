import java.util.PriorityQueue;

public class AdvanceQueue<T> extends PriorityQueue<T> {
    public T peekNext() {
        if (this.poll() == null)
            return null;
        T poll = this.poll();
        if (this.peek() == null)
            return null;
        T peek = this.peek();
        this.add(poll);
        return peek;
    }

    public void insertAtStart(T item) {
        PriorityQueue<T> newQueue = new PriorityQueue<>();
        newQueue.addAll(this);
        this.clear();
        this.add(item);
        this.addAll(newQueue);
    }
}
