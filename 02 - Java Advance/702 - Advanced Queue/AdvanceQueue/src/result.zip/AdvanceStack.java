import java.util.Stack;

public class AdvanceStack<T> extends Stack<T> {
    public T peekSecondLast() {
        if (this.size() < 2)
            return null;
        return this.get(1);
    }

    public void insertAtBottom(T item) {
        this.addFirst(item);
    }
}
