public class GuardianScroll {
    // TODO
}
