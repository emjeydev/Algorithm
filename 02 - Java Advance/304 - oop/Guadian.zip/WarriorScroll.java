public class WarriorScroll {
    // TODO
    public void AddAlliancePact(String pact){
        throw new UnsupportedOperationException("Not Implemented");
    }
}
