public class B707 extends Airplane{
    public B707(String name, int price, int numberOfSeats, int maxSpeed, String fuel, int numberOfFins, int numberOfWheels, String steeringWheel, String airline, int numberOfCrew, String captain) {
        super(name, price, numberOfSeats, maxSpeed, fuel, numberOfFins, numberOfWheels, steeringWheel, airline, numberOfCrew, captain);
    }
}
