public class Vehicle {
    String name;
    int price;
    int numberOfSeats;
    int maxSpeed;

    public Vehicle(String name, int price, int numberOfSeats, int maxSpeed) {
        this.name = name;
        this.price = price;
        this.numberOfSeats = numberOfSeats;
        this.maxSpeed = maxSpeed;
    }
}
