public class B707 extends Airplane{
    // implement B707 class
}
