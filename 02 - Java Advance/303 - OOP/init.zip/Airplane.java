public class Airplane extends FlyingVehicle {
    // implement Airplane class
}
