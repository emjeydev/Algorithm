public class FlyingVehicle extends Vehicle {
    // implement FlyingVehicle class
}
