public class Vehicle {
    // implement Vehicle class
}
