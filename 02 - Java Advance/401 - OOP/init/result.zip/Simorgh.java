public class Simorgh extends MythicalCreature {

    @Override
    public String performMagic() {
        return "The Simorgh heals the land with its feathers";
    }
}
