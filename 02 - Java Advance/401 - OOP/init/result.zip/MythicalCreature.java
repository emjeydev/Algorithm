public abstract class MythicalCreature {
    public abstract String performMagic();
}
