public class Div extends MythicalCreature {

    @Override
    public String performMagic() {
        return "The Div conjures fire and shadows";
    }
}
