public class Shah {
    public String commandCreatureToPerformMagic(MythicalCreature creature) {
        return creature.performMagic();
    }
}
