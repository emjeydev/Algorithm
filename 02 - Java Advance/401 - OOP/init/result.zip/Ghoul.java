public class Ghoul extends MythicalCreature {

    @Override
    public String performMagic() {
        return "The Ghoul transforms into a new shape";
    }
}
