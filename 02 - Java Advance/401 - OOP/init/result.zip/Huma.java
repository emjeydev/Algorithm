public class Huma extends MythicalCreature {

    @Override
    public String performMagic() {
        return "The Huma brings good fortune as it soars through the sky";
    }
}
