public class Simorgh extends MythicalCreature {

}
