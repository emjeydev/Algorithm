public class Ghoul extends MythicalCreature {

}
