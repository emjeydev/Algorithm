public class Div extends MythicalCreature {

}
