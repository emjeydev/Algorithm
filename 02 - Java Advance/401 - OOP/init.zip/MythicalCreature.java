public abstract class MythicalCreature {
    // write performMagic abstract method with String return type
}
