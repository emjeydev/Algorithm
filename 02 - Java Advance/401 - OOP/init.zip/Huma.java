public class Huma extends MythicalCreature {

}
