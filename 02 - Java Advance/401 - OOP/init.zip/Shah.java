public class Shah {
    public String commandCreatureToPerformMagic(MythicalCreature creature){
        throw new UnsupportedOperationException("Not Implemented");
    }
}
