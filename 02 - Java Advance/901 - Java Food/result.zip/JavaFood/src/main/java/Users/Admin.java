package Users;

public class Admin extends User {

    public Admin(int id, String name) {
        super(id, name);
    }
}