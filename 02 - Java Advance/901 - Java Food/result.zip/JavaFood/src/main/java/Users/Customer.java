package Users;

public class Customer extends User {

    public Customer(int id, String name) {
        super(id, name);
    }
}